class State:
    def __init__(self):
        self.percept = None
        self.time = 0
        self.people_saved = 0
        self.current_vertex = None

    def __str__(self):
        return ""

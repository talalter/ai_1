to run the code you need to run main.py, we used python 3.10.8
we imported some external libraries
to change the graph you need to change it in the file "input_graph.txt" and use the same format as
#N 4
#V1
#V2 P1 B
#V3 B
#V4 P2

#E1 1 2 W1
#E2 3 4 W1
#E3 2 3 W1
#E4 1 3 W4
#E5 2 4 W5

**please note for simplicity in our code we made it so that our verticies are numbered 1 integer below there there id such as 0-3 instead of 1-4


when you run the code you will be given options to input how many agents you want. which agent you want and there T and Limit